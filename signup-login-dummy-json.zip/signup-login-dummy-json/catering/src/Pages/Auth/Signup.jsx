import React, { useState } from 'react';

import { signupUser } from '../../Services/AuthServices';



const defaultValue = {
  name:"",
  email:"",
  phone:"",
  password:""
}

function Signup() {
  const [user, setUser] = useState(defaultValue);
  const [error, setError] = useState('');
 

  const onChangeValue = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
    console.log(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(user,"ppppppppppp")

    const result = await signupUser(user);
    console.log(result,"result")
    
 
  };

  return (
    <div className="signup-container">
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form className="signup-form" onSubmit={handleSubmit}>
        <h2>Register</h2>
        <label className="sign-text">Name</label>
        <input
          className="signup-input-box"
          type="text"
          placeholder="Enter First Name"
          onChange={onChangeValue}
          name="name"
          value={user.name}
        />

      

        <label className="sign-text">Email</label>
        <input
          className="signup-input-box"
          type="email"
          placeholder="Enter Email"
          onChange={onChangeValue}
          name="email"
          value={user.email}
        />

        <label className="sign-text">Phone Number</label>
        <input
          className="signup-input-box"
          type="phone"
          placeholder="Enter Phone Number"
          onChange={onChangeValue}
          name="phone"
          value={user.phone}
        />

        <label className="sign-text">Password</label>
        <input
          className="signup-input-box"
          type="password"
          placeholder="Enter Password"
          onChange={onChangeValue}
          name="password"
          value={user.password}
        />

     

        <button type="submit" className="signup-submit">
          Register
        </button>
      </form>
    </div>
  );
}

export default Signup;
