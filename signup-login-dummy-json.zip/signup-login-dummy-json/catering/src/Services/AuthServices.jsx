import data from '../../users.json';



// Mock function to simulate a backend signup
export const signupUser = (users) => {
console.log(users.email,"users------")
const userExists = data.users.find((existingUser) => existingUser.email === users.email);
  
  console.log(userExists, "existingUser");

  if (userExists) {
    
    console.log("User with this email already exists.");
    return { success: false, message: "Email already exists." };
  } else {
    const saveUser=data.users.push(users)
    console.log(saveUser,"saveUser")

    return { success: true, message: "Signup successful." };
  }

};
